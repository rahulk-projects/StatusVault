@echo off
setlocal
set "GRADLE_VERSION=8.9"
set "BASE_DIR=%USERPROFILE%\.gradle\statusvault-bootstrap"
set "GRADLE_HOME=%BASE_DIR%\gradle-%GRADLE_VERSION%"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%BASE_DIR%" mkdir "%BASE_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $root=Join-Path $env:USERPROFILE '.gradle\statusvault-bootstrap'; $zip=Join-Path $root 'gradle-8.9-bin.zip'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile $zip; Expand-Archive -LiteralPath $zip -DestinationPath $root -Force; Remove-Item $zip -Force"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
