# StatusVault — Android local status saver

StatusVault is a small Android app for saving status photos and videos that WhatsApp has already cached on your device. It uses Android's folder picker, previews media locally, supports selecting multiple items, and copies chosen files into your gallery.

## Privacy by design

- No WhatsApp login or account connection.
- No network permission and no uploads.
- No contacts, camera, microphone, or location permissions.
- Access is limited to the folder you select through Android's system picker.
- Photos are saved to `Pictures/StatusVault`; videos are saved to `Movies/StatusVault`.

Only status media already loaded/cached by WhatsApp can appear. Open a status in WhatsApp first, then return to StatusVault and tap **Refresh**. Cached statuses may disappear when WhatsApp removes them.

## Select the correct folder

On current Android versions, choose the **Media** folder, not the storage root. Common locations are:

- WhatsApp: `Android/media/com.whatsapp/WhatsApp/Media`
- WhatsApp Business: `Android/media/com.whatsapp.w4b/WhatsApp Business/Media`
- Older installs: `WhatsApp/Media`

StatusVault looks inside the selected folder for the hidden `.Statuses` subfolder. If your file picker can show hidden folders, you can select `.Statuses` directly instead. If nothing appears, verify that you viewed the status in WhatsApp and selected the correct account's Media folder.

## Build with Android Studio

1. Install Android Studio with Android SDK Platform 35 and a Java 17-compatible JDK.
2. Open the `StatusVault` project folder in Android Studio.
3. Allow Gradle to sync and download the declared AndroidX/Glide dependencies.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Install the generated debug APK on your Android phone. The project currently targets Android 14 (API 34) and requires Android 10 (API 29) or newer.

This environment did not have the Android SDK/Gradle build tool installed, so this package contains the complete Android Studio source project rather than a precompiled APK.


## Version 1.1.0 UI update
- Modern green hero header and cleaner folder connection card.
- Separate Photos and Videos tabs with live item counts.
- Switching tabs preserves selections across both media types.
- Taller media thumbnails and updated card styling.

## Launcher icon

The launcher icon uses a modern emerald media-vault design. Adaptive icon assets are in `res/mipmap-anydpi-v26` and `res/drawable-nodpi`; density-specific PNG fallbacks are included for older Android launchers.
