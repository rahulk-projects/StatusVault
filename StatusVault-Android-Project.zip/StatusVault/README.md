# StatusVault — ad-free WhatsApp Status Saver

StatusVault is a local-first Android app for saving photo and video statuses that WhatsApp has already cached on your device. It provides separate Photos and Videos sections, previews, bulk selection, gallery saving, and Android's native share sheet.

## Highlights

- **Ad-free by design** — no advertising SDKs are included.
- **WhatsApp-inspired theme** — deep green toolbar, bright green accents, and familiar tabs.
- **Separate photo and video galleries** with media counts.
- **Save or share** individual items or selected multiple items.
- **Help me** — step-by-step guidance for locating the correct `.Statuses` folder.
- **Local-first** — no WhatsApp login and no media upload to a StatusVault server.

## Connect the status folder

On first launch, StatusVault attempts to open the expected folder location:

`Android/media/com.whatsapp/WhatsApp/Media/.Statuses/`

Android still requires the user to confirm access in its system folder picker. If `.Statuses` is hidden or unavailable, choose the parent **Media** folder instead; StatusVault will look for `.Statuses` inside it. Use the **Help me** button in the app for step-by-step instructions.

WhatsApp Business commonly uses `Android/media/com.whatsapp.w4b/WhatsApp Business/Media`. Folder visibility can vary by Android version and file picker.

## Use the app

1. Open/view the statuses in WhatsApp first so their media is cached on the device.
2. Open StatusVault and grant access to the appropriate folder.
3. Browse the **Photos** or **Videos** tab.
4. Tap an item to preview it, or select multiple items.
5. Use **Save** to copy selected media into `Pictures/StatusVault` or `Movies/StatusVault`, or use **Share** to open Android's share sheet and choose WhatsApp or another compatible app.

StatusVault does not directly download files from WhatsApp's servers. It can only access media made available through the folder permission you grant. Cached files may disappear when WhatsApp removes them.

## Build from a phone with GitHub Actions

The workflow in `.github/workflows/android.yml` can build a debug APK in the cloud, without requiring Android Studio on your phone.

1. Commit the Android project files to your repository.
2. Open **Actions** and run **Build StatusVault APK**.
3. After a successful run, open its summary and download the `StatusVault-debug-apk` artifact.
4. Extract the artifact ZIP and install the APK.

A debug artifact is intended for personal/testing use; it is not a Play Store release. Your Android device may require confirmation to install apps from your browser or file manager. If an APK signature differs from the currently installed copy, Android may require uninstalling the older build first.

## Privacy and permissions

- No StatusVault account or WhatsApp credentials are required.
- The app is designed to operate locally and does not upload media to a server.
- Access is granted to the folder selected through Android's system picker.
- Review source code and requested permissions before installing builds from third parties.

## Compatibility

The project currently requires Android 10 (API 29) or newer and targets Android 14 (API 34). It uses Android's Storage Access Framework and MediaStore APIs. Folder access and visibility depend on Android/WhatsApp versions and the device's system picker.

## Disclaimer

StatusVault is an independent utility and is not affiliated with, endorsed by, or sponsored by WhatsApp or Meta. WhatsApp is a trademark of Meta Platforms, Inc. Please respect others' privacy and obtain permission before redistributing their photos or videos.

## Version

**1.3.0** — WhatsApp-inspired visual theme, persistent **Help me** entry points, and updated folder selection guidance.
