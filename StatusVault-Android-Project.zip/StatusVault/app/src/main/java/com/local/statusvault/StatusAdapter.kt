package com.local.statusvault

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal class StatusAdapter(
    private val context: Context,
    private val onPreview: (StatusItem) -> Unit,
    private val onSelectionChanged: (Int) -> Unit
) : RecyclerView.Adapter<StatusAdapter.StatusViewHolder>() {

    private var items: List<StatusItem> = emptyList()
    private var allItems: List<StatusItem> = emptyList()
    private val selectedKeys = linkedSetOf<String>()

    fun setItems(newItems: List<StatusItem>, selectionUniverse: List<StatusItem> = newItems) {
        items = newItems
        allItems = selectionUniverse
        selectedKeys.retainAll(allItems.map { it.uri.toString() }.toSet())
        notifyDataSetChanged()
        onSelectionChanged(selectedKeys.size)
    }

    fun selectedItems(): List<StatusItem> = allItems.filter { selectedKeys.contains(it.uri.toString()) }

    fun toggleAll() {
        if (items.isEmpty()) return
        val visibleKeys = items.map { it.uri.toString() }
        if (visibleKeys.all { selectedKeys.contains(it) }) selectedKeys.removeAll(visibleKeys.toSet())
        else selectedKeys.addAll(visibleKeys)
        notifyDataSetChanged()
        onSelectionChanged(selectedKeys.size)
    }

    fun clearSelectionFor(savedItems: Collection<StatusItem>) {
        savedItems.forEach { selectedKeys.remove(it.uri.toString()) }
        notifyDataSetChanged()
        onSelectionChanged(selectedKeys.size)
    }

    private fun toggle(item: StatusItem) {
        val key = item.uri.toString()
        if (!selectedKeys.add(key)) selectedKeys.remove(key)
        val position = items.indexOfFirst { it.uri == item.uri }
        if (position >= 0) notifyItemChanged(position)
        onSelectionChanged(selectedKeys.size)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StatusViewHolder {
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.WHITE, 18f)
            clipToOutline = true
            elevation = dp(2).toFloat()
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(dp(4), dp(5), dp(4), dp(7))
            }
        }

        val imageFrame = FrameLayout(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(166)
            )
            setBackgroundColor(Color.rgb(240, 242, 245))
        }
        val image = ImageView(context).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(240, 242, 245))
            contentDescription = "Status preview"
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        imageFrame.addView(image)

        val typeChip = TextView(context).apply {
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = rounded(0xCC075E54.toInt(), 30f)
        }
        imageFrame.addView(typeChip, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, dp(24), Gravity.TOP or Gravity.START
        ).apply { setMargins(dp(8), dp(8), 0, 0) })

        val selectChip = TextView(context).apply {
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(0xB30C2823.toInt(), 30f)
            contentDescription = "Select status"
            isClickable = true
            isFocusable = true
        }
        imageFrame.addView(selectChip, FrameLayout.LayoutParams(dp(32), dp(32), Gravity.TOP or Gravity.END)
            .apply { setMargins(0, dp(7), dp(7), 0) })

        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(9), dp(10), dp(11))
        }
        val filename = TextView(context).apply {
            // Keep the holder field for compatibility, but never expose raw source filenames in UI.
            visibility = View.GONE
            height = 0
        }
        val meta = TextView(context).apply {
            textSize = 11f
            setTextColor(Color.rgb(102, 119, 129))
            maxLines = 1
            setPadding(0, dp(4), 0, 0)
        }
        content.addView(filename, LinearLayout.LayoutParams(0, 0))
        content.addView(meta)
        card.addView(imageFrame)
        card.addView(content)

        return StatusViewHolder(card, image, typeChip, selectChip, filename, meta)
    }

    override fun onBindViewHolder(holder: StatusViewHolder, position: Int) {
        val item = items[position]
        val key = item.uri.toString()
        val selected = selectedKeys.contains(key)
        holder.filename.text = if (item.isVideo) "Video status" else "Photo status"
        holder.meta.text = "${formatSize(item.sizeBytes)}  ·  ${formatDate(item.modifiedAt)}"
        holder.typeChip.text = if (item.isVideo) "▶ VIDEO" else "PHOTO"
        holder.selectChip.text = if (selected) "✓" else "+"
        holder.selectChip.background = rounded(if (selected) 0xFF25D366.toInt() else 0xB3111B21.toInt(), 30f)
        Glide.with(holder.thumbnail).load(item.uri).centerCrop().into(holder.thumbnail)
        holder.itemView.setOnClickListener { onPreview(item) }
        holder.itemView.setOnLongClickListener {
            toggle(item)
            true
        }
        holder.selectChip.setOnClickListener { toggle(item) }
    }

    override fun getItemCount(): Int = items.size

    private fun formatDate(timestamp: Long): String {
        if (timestamp <= 0L) return "On device"
        return SimpleDateFormat("MMM d · h:mm a", Locale.getDefault()).format(Date(timestamp))
    }

    private fun formatSize(bytes: Long): String = when {
        bytes <= 0 -> "Media"
        bytes < 1024 * 1024 -> "${(bytes / 1024f).toInt().coerceAtLeast(1)} KB"
        else -> String.format(Locale.getDefault(), "%.1f MB", bytes / (1024f * 1024f))
    }

    private fun rounded(color: Int, radiusDp: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp.toInt()).toFloat()
    }

    private fun dp(value: Int): Int = (value * context.resources.displayMetrics.density).toInt()

    class StatusViewHolder(
        itemView: View,
        val thumbnail: ImageView,
        val typeChip: TextView,
        val selectChip: TextView,
        val filename: TextView,
        val meta: TextView
    ) : RecyclerView.ViewHolder(itemView)
}
