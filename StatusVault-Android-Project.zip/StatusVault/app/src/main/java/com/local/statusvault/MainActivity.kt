package com.local.statusvault

import android.app.Dialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.ClipData
import android.provider.DocumentsContract
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.documentfile.provider.DocumentFile
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyPanel: LinearLayout
    private lateinit var emptyTitle: TextView
    private lateinit var emptyDescription: TextView
    private lateinit var sourceDescription: TextView
    private lateinit var resultCount: TextView
    private lateinit var saveButton: Button
    private lateinit var shareButton: Button
    private lateinit var adapter: StatusAdapter
    private lateinit var photosTab: TextView
    private lateinit var videosTab: TextView
    private lateinit var photosIndicator: View
    private lateinit var videosIndicator: View
    private lateinit var listTitle: TextView

    private var selectedTreeUri: Uri? = null
    private var saving = false
    private var allStatuses: List<StatusItem> = emptyList()
    private var currentSection = MediaSection.PHOTOS

    private enum class MediaSection { PHOTOS, VIDEOS }

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            selectedTreeUri = uri
            getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                .putString(KEY_TREE_URI, uri.toString())
                .apply()
            updateSourceDescription(uri)
            reloadStatuses()
        } catch (_: SecurityException) {
            Toast.makeText(this, "Folder access was not granted. Please try again.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = color(COLOR_WHATSAPP_DARK)
        window.navigationBarColor = color(COLOR_BACKGROUND)
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = window.decorView.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        buildUi()

        val savedUri = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_TREE_URI, null)
        if (savedUri != null) {
            selectedTreeUri = Uri.parse(savedUri)
            updateSourceDescription(selectedTreeUri!!)
            reloadStatuses()
        } else {
            showEmptyState(
                "Your library starts here",
                "Allow access to your WhatsApp .Statuses folder to get started."
            )
            // Open the system picker at the preferred .Statuses location. Android still requires
            // the user to confirm folder access; manual selection remains available at all times.
            recyclerView.post { launchFolderPicker(true) }
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(color(COLOR_BACKGROUND))
        }

        // Compact WhatsApp-inspired toolbar: familiar deep green, clean typography, and Help me.
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(5), dp(12), dp(5))
            setBackgroundColor(color(COLOR_WHATSAPP_DARK))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58))
        }
        val logo = TextView(this).apply {
            text = "◉"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(COLOR_WHATSAPP_GREEN, 18)
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(38), dp(38)))

        val headingBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        headingBox.addView(textView("StatusVault", 19f, Color.WHITE, true))
        headingBox.addView(textView("Ad-free status saver", 10.5f, 0xFFD5EAE5.toInt(), false).apply {
            setPadding(0, dp(1), 0, 0)
        })
        header.addView(headingBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val helpButton = createButton("?  Help me", COLOR_WHATSAPP_BRIGHT, COLOR_WHATSAPP_DARK).apply {
            textSize = 12f
            minHeight = dp(38)
            minimumHeight = dp(38)
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { showFolderHelp() }
        }
        header.addView(helpButton)
        root.addView(header)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(3))
        }
        root.addView(content, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        // Small source panel keeps connection controls visible without sacrificing gallery space.
        val sourceCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = outlinedRounded(Color.WHITE, COLOR_BORDER, 16)
            setPadding(dp(11), dp(7), dp(11), dp(7))
        }
        val sourceTop = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val sourceLabels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sourceLabels.addView(textView("WHATSAPP STATUSES", 9.5f, COLOR_WHATSAPP_TEAL, true).apply {
            letterSpacing = 0.04f
        })
        sourceLabels.addView(textView("Connect media folder", 13f, COLOR_TEXT, true).apply {
            setPadding(0, dp(2), 0, 0)
        })
        sourceTop.addView(sourceLabels, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val chooseButton = createButton("Choose folder", COLOR_WHATSAPP_TEAL, Color.WHITE).apply {
            textSize = 12f
            minHeight = dp(36)
            minimumHeight = dp(36)
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { launchFolderPicker(true) }
        }
        sourceTop.addView(chooseButton)
        sourceCard.addView(sourceTop)
        sourceDescription = textView(
            "We'll try .Statuses first. Use Help me if you can't find it.",
            10.5f, COLOR_MUTED, false
        ).apply {
            setPadding(0, dp(4), 0, 0)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        sourceCard.addView(sourceDescription)
        val sourceParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        sourceParams.bottomMargin = dp(7)
        content.addView(sourceCard, sourceParams)

        // WhatsApp-like green section strip with a bright active underline.
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(color(COLOR_WHATSAPP_DARK))
        }
        val photosCell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        photosTab = TextView(this).apply {
            text = "▧   PHOTOS   ·   0"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(5), dp(11), dp(5), dp(10))
            setOnClickListener { switchSection(MediaSection.PHOTOS) }
        }
        photosIndicator = View(this).apply { setBackgroundColor(color(COLOR_WHATSAPP_BRIGHT)) }
        photosCell.addView(photosTab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(39)))
        photosCell.addView(photosIndicator, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))

        val videosCell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        videosTab = TextView(this).apply {
            text = "▶   VIDEOS   ·   0"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(0xFFBBDAD3.toInt())
            setPadding(dp(5), dp(11), dp(5), dp(10))
            setOnClickListener { switchSection(MediaSection.VIDEOS) }
        }
        videosIndicator = View(this).apply { setBackgroundColor(color(COLOR_WHATSAPP_DARK)) }
        videosCell.addView(videosTab, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(39)))
        videosCell.addView(videosIndicator, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))
        tabs.addView(photosCell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tabs.addView(videosCell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        content.addView(tabs)

        val listToolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(5), dp(2), dp(4))
        }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listTitle = textView("Photos", 16f, COLOR_TEXT, true)
        titleBox.addView(listTitle)
        resultCount = textView("0 items", 10.5f, COLOR_MUTED, false).apply { setPadding(0, dp(1), 0, 0) }
        titleBox.addView(resultCount)
        listToolbar.addView(titleBox, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val refreshButton = createButton("↻ Refresh", COLOR_WHITE, COLOR_TEXT).apply {
            textSize = 11.5f
            minHeight = dp(33)
            minimumHeight = dp(33)
            setPadding(dp(8), 0, dp(8), 0)
            background = outlinedRounded(Color.WHITE, COLOR_BORDER, 11)
            setOnClickListener { reloadStatuses() }
        }
        listToolbar.addView(refreshButton)
        val selectAllButton = createButton("Select all", COLOR_WHITE, COLOR_WHATSAPP_TEAL).apply {
            textSize = 11.5f
            minHeight = dp(33)
            minimumHeight = dp(33)
            setPadding(dp(8), 0, dp(8), 0)
            background = outlinedRounded(Color.WHITE, COLOR_BORDER, 11)
            setOnClickListener { adapter.toggleAll() }
        }
        val selectParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        selectParams.leftMargin = dp(6)
        listToolbar.addView(selectAllButton, selectParams)
        content.addView(listToolbar)

        val contentFrame = FrameLayout(this)
        recyclerView = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@MainActivity, 2)
            clipToPadding = false
            setPadding(0, dp(1), 0, dp(5))
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        contentFrame.addView(recyclerView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))

        emptyPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        val emptyIcon = TextView(this).apply {
            text = "◉"
            textSize = 32f
            setTextColor(color(COLOR_WHATSAPP_TEAL))
            gravity = Gravity.CENTER
            background = rounded(COLOR_MINT, 22)
        }
        emptyPanel.addView(emptyIcon, LinearLayout.LayoutParams(dp(64), dp(64)))
        emptyTitle = textView("Your library starts here", 16f, COLOR_TEXT, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(13), 0, dp(2))
        }
        emptyPanel.addView(emptyTitle)
        emptyDescription = textView("Connect your WhatsApp .Statuses folder to get started.", 12f, COLOR_MUTED, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, 0)
        }
        emptyPanel.addView(emptyDescription)
        val emptyHelp = createButton("Help me find the folder", COLOR_MINT, COLOR_WHATSAPP_TEAL).apply {
            textSize = 12f
            minHeight = dp(38)
            minimumHeight = dp(38)
            setOnClickListener { showFolderHelp() }
        }
        val emptyHelpParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38))
        emptyHelpParams.topMargin = dp(12)
        emptyPanel.addView(emptyHelp, emptyHelpParams)
        contentFrame.addView(emptyPanel, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        content.addView(contentFrame, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(5), 0, dp(1))
        }
        saveButton = createButton("↓  Save (0)", 0xFFB9DCCB.toInt(), COLOR_WHATSAPP_DARK).apply {
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            minHeight = dp(46)
            minimumHeight = dp(46)
            isEnabled = false
            setOnClickListener { saveItems(adapter.selectedItems()) }
        }
        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        actionRow.addView(saveButton, LinearLayout.LayoutParams(0, dp(44), 1f))
        shareButton = createButton("↗  Share", COLOR_MINT, COLOR_WHATSAPP_TEAL).apply {
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            minHeight = dp(44)
            minimumHeight = dp(44)
            isEnabled = false
            setOnClickListener { shareItems(adapter.selectedItems()) }
        }
        val shareParams = LinearLayout.LayoutParams(0, dp(44), 0.72f)
        shareParams.leftMargin = dp(7)
        actionRow.addView(shareButton, shareParams)
        footer.addView(actionRow)
        footer.addView(textView("Save to your phone or share with WhatsApp", 9.5f, COLOR_MUTED, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(3), 0, 0)
        })
        content.addView(footer)

        setContentView(root)
        adapter = StatusAdapter(this, ::showPreview) { count -> updateSaveButton(count) }
        recyclerView.adapter = adapter
        updateSectionTabs()
    }

    private fun showFolderHelp() {
        val message = "Follow these steps to connect your WhatsApp statuses:\n\n" +
            "1. Open WhatsApp and view the statuses you want to save first.\n\n" +
            "2. In the folder picker, open Internal storage → Android → media → com.whatsapp → WhatsApp → Media.\n\n" +
            "3. If you can see .Statuses, select that folder. If it is hidden or not listed, select the Media folder instead; StatusVault will look for .Statuses inside it.\n\n" +
            "4. Tap ‘Use this folder’ and then ‘Allow’ if Android asks for confirmation.\n\n" +
            "WhatsApp Business may use Android/media/com.whatsapp.w4b/WhatsApp Business/Media.\n\n" +
            "Android controls folder permissions, so you must confirm access in the system picker."

        AlertDialog.Builder(this)
            .setTitle("Help me find .Statuses")
            .setMessage(message)
            .setPositiveButton("Choose folder") { _, _ -> launchFolderPicker(true) }
            .setNegativeButton("Got it", null)
            .show()
    }

    private fun launchFolderPicker(preferStatuses: Boolean = true) {
        val initialUri = if (preferStatuses) preferredStatusesDocumentUri() else null
        if (!preferStatuses) {
            Toast.makeText(this, "Choose the .Statuses folder, or choose WhatsApp → Media if needed.", Toast.LENGTH_LONG).show()
        }
        folderPicker.launch(initialUri)
    }

    private fun preferredStatusesDocumentUri(): Uri? = try {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            DocumentsContract.buildDocumentUri(
                "com.android.externalstorage.documents",
                "primary:Android/media/com.whatsapp/WhatsApp/Media/.Statuses"
            )
        } else null
    } catch (_: Exception) { null }

    private fun updateSourceDescription(uri: Uri) {
        val folderName = try { DocumentFile.fromTreeUri(this, uri)?.name } catch (_: Exception) { null }
        sourceDescription.text = if (folderName.isNullOrBlank()) {
            "Folder connected. StatusVault only reads the .Statuses subfolder."
        } else {
            "Connected: $folderName · StatusVault only reads .Statuses media."
        }
    }

    private fun reloadStatuses() {
        val treeUri = selectedTreeUri
        if (treeUri == null) {
            allStatuses = emptyList()
            updateMediaSections()
            showEmptyState("Choose a status folder", "Select WhatsApp → Media, or select .Statuses directly if hidden folders are shown.")
            return
        }

        showEmptyState("Checking your folder…", "Looking only for cached photos and videos in .Statuses.")
        Thread {
            val result = try {
                scanStatuses(treeUri)
            } catch (_: SecurityException) {
                ScanResult(emptyList(), "Folder permission expired", "Choose the folder again to restore access.")
            } catch (_: Exception) {
                ScanResult(emptyList(), "Couldn't read this folder", "Try selecting WhatsApp → Media or .Statuses again.")
            }
            runOnUiThread {
                allStatuses = result.items
                updateMediaSections()
                if (result.items.isEmpty()) showEmptyState(result.emptyTitle, result.emptyDescription)
            }
        }.start()
    }

    private fun switchSection(section: MediaSection) {
        if (currentSection == section) return
        currentSection = section
        updateSectionTabs()
        updateMediaSections()
    }

    private fun updateSectionTabs() {
        if (!::photosTab.isInitialized || !::videosTab.isInitialized) return
        val photoCount = allStatuses.count { !it.isVideo }
        val videoCount = allStatuses.count { it.isVideo }
        photosTab.text = "▧   PHOTOS   ·   $photoCount"
        videosTab.text = "▶   VIDEOS   ·   $videoCount"
        val photosSelected = currentSection == MediaSection.PHOTOS
        photosTab.setTextColor(color(if (photosSelected) Color.WHITE else 0xFFBBDAD3.toInt()))
        videosTab.setTextColor(color(if (!photosSelected) Color.WHITE else 0xFFBBDAD3.toInt()))
        if (::photosIndicator.isInitialized) {
            photosIndicator.setBackgroundColor(color(if (photosSelected) COLOR_WHATSAPP_BRIGHT else COLOR_WHATSAPP_DARK))
            videosIndicator.setBackgroundColor(color(if (!photosSelected) COLOR_WHATSAPP_BRIGHT else COLOR_WHATSAPP_DARK))
        }
    }

    private fun updateMediaSections() {
        if (!::adapter.isInitialized) return
        val filtered = allStatuses.filter { if (currentSection == MediaSection.PHOTOS) !it.isVideo else it.isVideo }
        adapter.setItems(filtered, allStatuses)
        if (::listTitle.isInitialized) listTitle.text = if (currentSection == MediaSection.PHOTOS) "Photos" else "Videos"
        if (::resultCount.isInitialized) resultCount.text = when (filtered.size) {
            1 -> "1 ${if (currentSection == MediaSection.PHOTOS) "photo" else "video"}"
            else -> "${filtered.size}" + if (currentSection == MediaSection.PHOTOS) " photos" else " videos"
        }
        updateSectionTabs()
        if (allStatuses.isEmpty()) return
        if (filtered.isEmpty()) {
            showEmptyState(
                if (currentSection == MediaSection.PHOTOS) "No photos found" else "No videos found",
                if (currentSection == MediaSection.PHOTOS) "Your cached videos are here. Switch to Videos, or refresh after opening more statuses." else "Your cached photos are here. Switch to Photos, or refresh after opening more statuses."
            )
        } else {
            emptyPanel.visibility = View.GONE
        }
    }

    private fun scanStatuses(treeUri: Uri): ScanResult {
        val root = DocumentFile.fromTreeUri(this, treeUri)
            ?: return ScanResult(emptyList(), "Folder unavailable", "Choose the WhatsApp Media folder again.")
        val statusDirectory = locateStatusesFolder(root)
            ?: return ScanResult(
                emptyList(),
                "Couldn't find .Statuses",
                "Choose WhatsApp → Media, or open the picker's menu and enable hidden files to select .Statuses directly."
            )

        val files = statusDirectory.listFiles().filter { it.isFile }
        val media = files.mapNotNull { file ->
            val name = file.name ?: return@mapNotNull null
            val mime = resolveMimeType(file.uri, name) ?: return@mapNotNull null
            StatusItem(file.uri, name, mime, file.length(), file.lastModified())
        }.sortedByDescending { it.modifiedAt }

        return if (media.isEmpty()) {
            ScanResult(
                emptyList(),
                "No cached statuses yet",
                "Open the statuses you want to keep in WhatsApp first, then tap Refresh. Cached files may disappear when the status expires."
            )
        } else {
            ScanResult(media, "", "")
        }
    }

    private fun locateStatusesFolder(root: DocumentFile): DocumentFile? {
        if (root.name.equals(".Statuses", ignoreCase = true)) return root
        root.findFile(".Statuses")?.let { return it }

        val paths = listOf(
            listOf("Media", ".Statuses"),
            listOf("WhatsApp", "Media", ".Statuses"),
            listOf("WhatsApp Business", "Media", ".Statuses"),
            listOf("com.whatsapp", "WhatsApp", "Media", ".Statuses"),
            listOf("com.whatsapp.w4b", "WhatsApp Business", "Media", ".Statuses")
        )
        for (path in paths) {
            var current: DocumentFile? = root
            for (part in path) current = current?.findFile(part)
            if (current != null && current.isDirectory) return current
        }
        return null
    }

    private fun resolveMimeType(uri: Uri, name: String): String? {
        val reported = try { contentResolver.getType(uri) } catch (_: Exception) { null }
        if (!reported.isNullOrBlank() && (reported.startsWith("image/") || reported.startsWith("video/"))) return reported
        return when (name.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
            "jpg", "jpeg", "jpe" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "bmp" -> "image/bmp"
            "heic" -> "image/heic"
            "heif" -> "image/heif"
            "mp4", "m4v" -> "video/mp4"
            "3gp" -> "video/3gpp"
            "mov" -> "video/quicktime"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            else -> null
        }
    }

    private fun showPreview(item: StatusItem) {
        val dialog = Dialog(this)
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF091511.toInt())
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(12), 0)
        }
        val previewTitle = textView("Preview", 16f, Color.WHITE, true)
        top.addView(previewTitle, LinearLayout.LayoutParams(0, dp(54), 1f))
        val close = TextView(this).apply {
            text = "×"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            isClickable = true
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { dialog.dismiss() }
        }
        top.addView(close, LinearLayout.LayoutParams(dp(46), dp(54)))
        panel.addView(top)

        val mediaArea = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        if (item.isVideo) {
            val videoView = VideoView(this)
            mediaArea.addView(videoView, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            ))
            videoView.setVideoURI(item.uri)
            videoView.setMediaController(MediaController(this).apply { setAnchorView(videoView) })
        } else {
            val imageView = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
            mediaArea.addView(imageView, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            ))
            Glide.with(this).load(item.uri).fitCenter().into(imageView)
        }
        panel.addView(mediaArea, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(18))
        }
        bottom.addView(textView(if (item.isVideo) "Video status" else "Photo status", 13f, 0xFFD4E2DD.toInt(), true).apply {
            setPadding(0, 0, 0, dp(10))
        })
        val saveSingle = createButton("Save to phone", COLOR_GREEN, Color.WHITE).apply {
            minHeight = dp(48)
            setOnClickListener {
                dialog.dismiss()
                saveItems(listOf(item))
            }
        }
        bottom.addView(saveSingle, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
        val shareSingle = createButton("↗  Share", 0xFF1D8067.toInt(), Color.WHITE).apply {
            minHeight = dp(46)
            setOnClickListener { dialog.dismiss(); shareItems(listOf(item)) }
        }
        val shareSingleParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46))
        shareSingleParams.topMargin = dp(8)
        bottom.addView(shareSingle, shareSingleParams)
        panel.addView(bottom)
        dialog.setContentView(panel)
        dialog.window?.let { window ->
            window.setBackgroundDrawableResource(android.R.color.transparent)
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
        }
        dialog.show()
        dialog.window?.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
    }

    private fun shareItems(items: List<StatusItem>) {
        if (items.isEmpty()) {
            Toast.makeText(this, "Select at least one photo or video to share.", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val uris = ArrayList(items.map { it.uri })
            val intent = if (uris.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = items.first().mimeType
                    putExtra(Intent.EXTRA_STREAM, uris.first())
                }
            } else {
                val commonType = if (items.all { it.isVideo }) "video/*" else if (items.all { !it.isVideo }) "image/*" else "*/*"
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = commonType
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                }
            }
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (uris.isNotEmpty()) {
                val clip = ClipData.newUri(contentResolver, "StatusVault media", uris.first())
                for (uri in uris.drop(1)) clip.addItem(ClipData.Item(uri))
                intent.clipData = clip
            }
            startActivity(Intent.createChooser(intent, "Share status using"))
        } catch (_: Exception) {
            Toast.makeText(this, "Couldn't open sharing options for these files.", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveItems(items: List<StatusItem>) {
        if (items.isEmpty() || saving) return
        saving = true
        updateSaveButton(adapter.selectedItems().size)
        Thread {
            var savedCount = 0
            var failedCount = 0
            for (item in items) {
                try {
                    saveOne(item)
                    savedCount++
                } catch (_: Exception) {
                    failedCount++
                }
            }
            runOnUiThread {
                saving = false
                adapter.clearSelectionFor(items)
                updateSaveButton(adapter.selectedItems().size)
                val message = when {
                    failedCount == 0 -> if (savedCount == 1) "Saved to your phone" else "Saved $savedCount files to your phone"
                    savedCount == 0 -> "Couldn't save these files. Check device storage and try again."
                    else -> "Saved $savedCount · $failedCount failed"
                }
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun saveOne(item: StatusItem) {
        val isVideo = item.isVideo
        val collection = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val relativePath = if (isVideo) "Movies/StatusVault" else "Pictures/StatusVault"
        val displayName = makeUniqueName(collection, relativePath, safeFileName(item.name))
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, item.mimeType)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val destination = contentResolver.insert(collection, values)
            ?: throw IOException("Could not create destination media record")
        try {
            val input = contentResolver.openInputStream(item.uri) ?: throw IOException("Cannot read source media")
            input.use { source ->
                val output = contentResolver.openOutputStream(destination, "w") ?: throw IOException("Cannot write media")
                output.use { target -> source.copyTo(target) }
            }
            val published = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            contentResolver.update(destination, published, null, null)
        } catch (error: Exception) {
            contentResolver.delete(destination, null, null)
            throw error
        }
    }

    private fun makeUniqueName(collection: Uri, relativePath: String, original: String): String {
        val dot = original.lastIndexOf('.')
        val base = if (dot > 0) original.substring(0, dot) else original
        val extension = if (dot > 0) original.substring(dot) else ""
        var candidate = original
        var suffix = 1
        while (true) {
            val exists = contentResolver.query(
                collection,
                arrayOf(MediaStore.MediaColumns.DISPLAY_NAME),
                "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.DISPLAY_NAME}=?",
                arrayOf(relativePath, candidate),
                null
            ).use { cursor -> cursor?.moveToFirst() == true }
            if (!exists) return candidate
            candidate = "$base ($suffix)$extension"
            suffix++
        }
    }

    private fun safeFileName(raw: String): String {
        val cleaned = raw.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("[\\u0000-\\u001F]"), "_")
            .trim()
        return cleaned.takeIf { it.isNotBlank() && it != "." && it != ".." } ?: "Status_${System.currentTimeMillis()}"
    }

    private fun updateSaveButton(selectedCount: Int) {
        if (!::saveButton.isInitialized) return
        saveButton.text = if (saving) "Saving…" else "↓  Save ($selectedCount)"
        saveButton.isEnabled = selectedCount > 0 && !saving
        saveButton.background = rounded(if (saveButton.isEnabled) COLOR_GREEN else 0xFF9AB8AE.toInt(), 16)
        if (::shareButton.isInitialized) {
            shareButton.isEnabled = selectedCount > 0 && !saving
            shareButton.alpha = if (shareButton.isEnabled) 1f else 0.55f
        }
    }

    private fun showEmptyState(title: String, description: String) {
        emptyTitle.text = title
        emptyDescription.text = description
        emptyPanel.visibility = View.VISIBLE
    }

    private fun createButton(label: String, backgroundColor: Int, textColor: Int): Button = Button(this).apply {
        text = label
        textSize = 14f
        setAllCaps(false)
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(textColor)
        background = rounded(backgroundColor, 14)
        stateListAnimator = null
        minHeight = dp(44)
        minimumHeight = dp(44)
        setPadding(dp(14), dp(6), dp(14), dp(6))
    }

    private fun textView(text: String, size: Float, textColor: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color(textColor))
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(colorValue: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color(colorValue))
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun outlinedRounded(colorValue: Int, strokeColor: Int, radiusDp: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color(colorValue))
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(1), color(strokeColor))
    }

    private fun color(value: Int): Int = if (value in -0x1000000..-1) value else value

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private data class ScanResult(
        val items: List<StatusItem>,
        val emptyTitle: String,
        val emptyDescription: String
    )

    companion object {
        private const val PREFS_NAME = "status_vault_preferences"
        private const val KEY_TREE_URI = "status_tree_uri"

        // WhatsApp-inspired palette: deep teal toolbar, green action accent, soft neutral surface.
        private val COLOR_BACKGROUND = 0xFFF7F8FA.toInt()
        private val COLOR_TEXT = 0xFF111B21.toInt()
        private val COLOR_MUTED = 0xFF667781.toInt()
        private val COLOR_GREEN = 0xFF25D366.toInt()
        private val COLOR_GREEN_DARK = 0xFF075E54.toInt()
        private val COLOR_WHATSAPP_TEAL = 0xFF128C7E.toInt()
        private val COLOR_WHATSAPP_GREEN = 0xFF128C7E.toInt()
        private val COLOR_WHATSAPP_BRIGHT = 0xFF25D366.toInt()
        private val COLOR_WHATSAPP_DARK = 0xFF075E54.toInt()
        private val COLOR_MINT = 0xFFD9FDD3.toInt()
        private val COLOR_BORDER = 0xFFE9EDEF.toInt()
        private val COLOR_WHITE = 0xFFFFFFFF.toInt()
    }
}
