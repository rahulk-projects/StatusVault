package com.local.statusvault

import android.net.Uri

internal data class StatusItem(
    val uri: Uri,
    val name: String,
    val mimeType: String,
    val sizeBytes: Long,
    val modifiedAt: Long
) {
    val isVideo: Boolean
        get() = mimeType.startsWith("video/") ||
            name.substringAfterLast('.', "").lowercase() in setOf("mp4", "3gp", "m4v", "mov", "webm", "mkv")
}
